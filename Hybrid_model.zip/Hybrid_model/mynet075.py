import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import DropPath
from einops import rearrange
# Unfold模块使用给定的kernel_size对输入进行展开
class Unfold(nn.Module):
    def __init__(self, kernel_size=3):
        super().__init__()
# kernel_size定义了展开操作的窗口大小
        self.kernel_size = kernel_size
# 初始化权重为单位矩阵，使得每个窗口内的元素直接复制到输出
        weights = torch.eye(kernel_size ** 2)
        weights = weights.reshape(kernel_size ** 2, 1, kernel_size, kernel_size)
        # 将权重设置为不需要梯度，因为它们不会在训练过程中更新
        self.weights = nn.Parameter(weights, requires_grad=False)

    def forward(self, x):   # 获取输入的批量大小、通道数、高度和宽度
        b, c, h, w = x.shape
         # 使用定义好的权重对输入进行卷积操作，实现展开功能
        x = F.conv2d(x.reshape(b * c, 1, h, w), self.weights, stride=1, padding=self.kernel_size // 2)
         # 调整输出的形状，使其包含展开的窗口
        return x.reshape(b, c * 9, h * w)

# Fold模块与Unfold相反，用于将展开的特征图折叠回原始形状
class Fold(nn.Module):
    def __init__(self, kernel_size=3):
        super().__init__()

        self.kernel_size = kernel_size
		 # 与Unfold相同，初始化权重为单位矩阵
        weights = torch.eye(kernel_size ** 2)
        weights = weights.reshape(kernel_size ** 2, 1, kernel_size, kernel_size)
         # 权重不需要梯度
        self.weights = nn.Parameter(weights, requires_grad=False)

    def forward(self, x):
        b, _, h, w = x.shape
        # 使用转置卷积（逆卷积）操作恢复原始大小的特征图
        x = F.conv_transpose2d(x, self.weights, stride=1, padding=self.kernel_size // 2)
        return x

# Attention模块实现自注意力机制
class Attention(nn.Module):
    def __init__(self, dim, window_size=None, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()

        self.dim = dim# dim定义了特征维度，num_heads定义了注意力头的数量
        self.num_heads = num_heads
        head_dim = dim // num_heads

        self.window_size = window_size
# 根据给定的尺度因子或自动计算的尺度进行缩放
        self.scale = qk_scale or head_dim ** -0.5
 # qkv用一个卷积层同时生成查询、键和值
        self.qkv = nn.Conv2d(dim, dim * 3, 1, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Conv2d(dim, dim, 1)  # proj是输出的投影层
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, C, H, W = x.shape # 获取输入的形状
        N = H * W
# 将qkv的输出重塑为适合自注意力计算的形状
        q, k, v = self.qkv(x).reshape(B, self.num_heads, C // self.num_heads * 3, N).chunk(3,
                                                                                           dim=2)  # (B, num_heads, head_dim, N)
 # 计算注意力分数，注意力分数乘以尺度因子
        attn = (k.transpose(-1, -2) @ q) * self.scale
  # 应用softmax获取注意力权重
        attn = attn.softmax(dim=-2)  # (B, h, N, N)
    # 应用注意力dropout
        attn = self.attn_drop(attn)

        x = (v @ attn).reshape(B, C, H, W)

        x = self.proj(x)
        x = self.proj_drop(x)
        return x

# StokenAttention模块通过迭代地细化空间Token以增强特征表示
class StokenAttention(nn.Module):
    def __init__(self, dim, stoken_size, n_iter=1, num_heads=16, qkv_bias=False, qk_scale=None, attn_drop=0.,
                 proj_drop=0.):
        super().__init__()

        self.n_iter = n_iter
        self.stoken_size = stoken_size

        self.scale = dim ** - 0.5

        self.unfold = Unfold(3)
        self.fold = Fold(3)

        self.stoken_refine = Attention(dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
                                       attn_drop=attn_drop, proj_drop=proj_drop)

    def stoken_forward(self, x):
        '''
           x: (B, C, H, W)
        '''
        B, C, H0, W0 = x.shape
        h, w = self.stoken_size
 # 计算padding
        pad_l = pad_t = 0
        pad_r = (w - W0 % w) % w
        pad_b = (h - H0 % h) % h
        if pad_r > 0 or pad_b > 0:
            x = F.pad(x, (pad_l, pad_r, pad_t, pad_b))

        _, _, H, W = x.shape

        hh, ww = H // h, W // w
 # 使用自适应平均池化得到空间Token的特征
        stoken_features = F.adaptive_avg_pool2d(x, (hh, ww))  # (B, C, hh, ww)
  # 展开特征以进行精细化处理
        pixel_features = x.reshape(B, C, hh, h, ww, w).permute(0, 2, 4, 3, 5, 1).reshape(B, hh * ww, h * w, C)
 # 使用没有梯度的操作进行迭代精细化
        with torch.no_grad():
            for idx in range(self.n_iter):
                stoken_features = self.unfold(stoken_features)  # (B, C*9, hh*ww)
                stoken_features = stoken_features.transpose(1, 2).reshape(B, hh * ww, C, 9)
                affinity_matrix = pixel_features @ stoken_features * self.scale  # (B, hh*ww, h*w, 9)

                affinity_matrix = affinity_matrix.softmax(-1)  # (B, hh*ww, h*w, 9)

                affinity_matrix_sum = affinity_matrix.sum(2).transpose(1, 2).reshape(B, 9, hh, ww)

                affinity_matrix_sum = self.fold(affinity_matrix_sum)
                if idx < self.n_iter - 1:
                    stoken_features = pixel_features.transpose(-1, -2) @ affinity_matrix  # (B, hh*ww, C, 9)

                    stoken_features = self.fold(stoken_features.permute(0, 2, 3, 1).reshape(B * C, 9, hh, ww)).reshape(
                        B, C, hh, ww)

                    stoken_features = stoken_features / (affinity_matrix_sum + 1e-12)  # (B, C, hh, ww)

        stoken_features = pixel_features.transpose(-1, -2) @ affinity_matrix  # (B, hh*ww, C, 9)

        stoken_features = self.fold(stoken_features.permute(0, 2, 3, 1).reshape(B * C, 9, hh, ww)).reshape(B, C, hh, ww)

        stoken_features = stoken_features / (affinity_matrix_sum.detach() + 1e-12)  # (B, C, hh, ww)

        stoken_features = self.stoken_refine(stoken_features)

        stoken_features = self.unfold(stoken_features)  # (B, C*9, hh*ww)
        stoken_features = stoken_features.transpose(1, 2).reshape(B, hh * ww, C, 9)  # (B, hh*ww, C, 9)
# 通过affinity_matrix将精细化的特征映射回原始像素级别
        pixel_features = stoken_features @ affinity_matrix.transpose(-1, -2)  # (B, hh*ww, C, h*w)
 # 折叠特征，恢复原始形状
        pixel_features = pixel_features.reshape(B, hh, ww, C, h, w).permute(0, 3, 1, 4, 2, 5).reshape(B, C, H, W)

        if pad_r > 0 or pad_b > 0:
            pixel_features = pixel_features[:, :, :H0, :W0]

        return pixel_features

    def direct_forward(self, x): # 直接对x应用Attention进行细化
        B, C, H, W = x.shape
        stoken_features = x
        stoken_features = self.stoken_refine(stoken_features)
        return stoken_features

    def forward(self, x):
        if self.stoken_size[0] > 1 or self.stoken_size[1] > 1:
            return self.stoken_forward(x)
        else:
            return self.direct_forward(x)

class Pconv(nn.Module):
    def __init__(self, dim, n_div, forward='split_cat', kernel_size=7):
        super().__init__()
        self.dim = dim
        self.n_div = n_div
        self.forward_method = forward
        self.kernel_size = kernel_size
        self.convs = nn.ModuleList(
            [nn.Conv2d(dim // n_div, dim // n_div, kernel_size=kernel_size, padding=kernel_size // 2) for _ in range(n_div)]
        )

    def forward(self, x):
        if self.forward_method == 'split_cat':
            split_x = torch.chunk(x, self.n_div, dim=1)
            out = [conv(split_x[i]) for i, conv in enumerate(self.convs)]
            return torch.cat(out, dim=1)
        else:
            raise ValueError(f"Unknown forward method: {self.forward_method}")

class SE_Module(nn.Module):
    def __init__(self, channel, ratio=16):
        super(SE_Module, self).__init__()
        reduced_channels = max(channel // ratio, 1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(channel, reduced_channels, kernel_size=1, padding=0)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(reduced_channels, channel, kernel_size=1, padding=0)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.fc1(y)
        y = self.relu(y)
        y = self.fc2(y)
        y = self.sigmoid(y)
        return x * y

class LayerNorm2d(nn.Module):
    def __init__(self, normalized_shape, eps=1e-6, elementwise_affine=True):
        super().__init__()
        self.norm = nn.LayerNorm(normalized_shape, eps, elementwise_affine)

    def forward(self, x):
        x = rearrange(x, 'b c h w -> b h w c').contiguous()
        x = self.norm(x)
        x = rearrange(x, 'b h w c -> b c h w').contiguous()
        return x

class LFAEncoder(nn.Module):
    def __init__(self, dim, drop_path=0., layer_scale_init_value=1e-6, expan_ratio=4.0, kernel_s=7, downsample=True):
        super().__init__()
        self.dwconv1 = nn.Conv2d(dim, dim, kernel_size=3, padding=3//2, groups=dim)
        # Pconv : https://arxiv.org/abs/2303.03667
        self.dwconv2 = Pconv(dim=dim, n_div=4, forward='split_cat', kernel_size=kernel_s)
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pwconv1 = nn.Linear(dim, int(expan_ratio * dim))
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(int(expan_ratio * dim), dim)
        # SE_Module : https://arxiv.org/abs/1709.01507
        self.se = SE_Module(channel=dim, ratio=16)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.downsample = nn.Conv2d(dim, dim, kernel_size=3, stride=2, padding=1) if downsample else nn.Identity()

    def forward(self, x):
        input = x
        x = self.dwconv2(self.dwconv1(x) + input)
        x = x.permute(0, 2, 3, 1)  # (N, C, H, W) -> (N, H, W, C)
        x = self.pwconv2(self.act(self.pwconv1(self.norm(x))))
        x = x.permute(0, 3, 1, 2)  # (N, H, W, C) -> (N, C, H, W)
        x = self.se(input + self.drop_path(x))
        x = self.downsample(x)
        return x
class LFAStokenNetwork(nn.Module):
    def __init__(self, dim, stoken_size, n_iter=1, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0.,
                 proj_drop=0., drop_path=0., layer_scale_init_value=1e-6, expan_ratio=4.0, kernel_s=7,downsample=True):
        super().__init__()
        self.encoder = LFAEncoder(dim, drop_path, layer_scale_init_value, expan_ratio, kernel_s,downsample=downsample)
        self.stoken_attention = StokenAttention(dim, stoken_size, n_iter, num_heads, qkv_bias, qk_scale, attn_drop, proj_drop)

    def forward(self, x):
        shortcut = x
        x = self.encoder(x) + shortcut
        shortcut = x
        x = self.stoken_attention(x) + shortcut

        return x
class mynet(nn.Module):

    def __init__(self,  num_classes):
        self.inplanes = 32
        super(mynet, self).__init__()
        #self.conv = nn.Conv2d(1, 32, kernel_size=7, stride=2, padding=(54,375))
        #self.conv = nn.Conv2d(1, 32, kernel_size=7, stride=2, padding=(54,197))
        self.conv = nn.Conv2d(1, 16, kernel_size=7, stride=1, padding=(3, 3))
        self.conv2 = nn.Conv2d(16, 16, kernel_size=3, stride=2, padding=(1,1))
        self.BN = nn.BatchNorm2d(16)
        
        self.relu = nn.ReLU(inplace=True)
        self.LS = LFAStokenNetwork(16, stoken_size=[4,4],downsample=False)
        self.conv1 = nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=(1,1))
        self.BN1 = nn.BatchNorm2d(32)
        self.LS1 = LFAStokenNetwork(32, stoken_size=[8,8],downsample=False)
        self.avgpool = nn.AvgPool2d(2)
        self.fc = nn.LazyLinear(num_classes)


    def forward(self, x):
        x = self.conv(x)
        x = self.conv2(x)
        x = self.BN(x)
        x = self.relu(x)
        x = self.LS(x)
        x = self.conv1(x)
        x = self.BN1(x)
        x = self.relu(x)
        x = self.LS1(x)
        #print(x.shape)
        #x = self.iRMB1(x)
        #x = self.iRMB1(x)
        #x = self.iRMB1(x)
        #print(x.shape)
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)

        x = self.fc(x)

        return x
model = mynet(7)
from torchsummary import summary
if __name__=='__main__':
    #model = torchvision.models.resnet50()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    #print(model)
    print(summary(model, (1, 224, 224)))