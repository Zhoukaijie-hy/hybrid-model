from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import numpy as np

def confusion(y_pred,y_true,labels):
    # y_pred = [] # ['2','2','3','1','4'] # 类似的格式
    # y_true = [] # ['0','1','2','3','4'] # 类似的格式
    # 对上面进行赋值

    C = confusion_matrix(y_true, y_pred, labels=labels) # 可将'1'等替换成自己的类别，如'cat'。
    # 转换成概率矩阵，即每一行（每一个类别）的元素和为1，且保留2位小数
    
    C = C.astype('float') / C.sum(axis=1)[:, np.newaxis]
    C = np.around(C, decimals=2)
    plt.matshow(C, cmap=plt.cm.Oranges) # 根据最下面的图按自己需求更改颜色
    #plt.colorbar() # 显示颜色条
    #显示colorbar，并且设置其位置
    plt.colorbar(shrink=0.8)


     # 在混淆矩阵的每个格子中添加数值标签
    for i in range(len(C)):
        for j in range(len(C)):
            # 如果在对角线上，字体颜色为白色；否则为黑色
            color = 'white' if i == j else 'black'
            plt.annotate(C[j, i], xy=(i, j), horizontalalignment='center', verticalalignment='center', fontsize=12, color=color)

    # 设置坐标轴的标签字体和标题字体
    plt.ylabel('True label', fontdict={'family': 'Times New Roman', 'size': 12})
    plt.xlabel('Predicted label', fontdict={'family': 'Times New Roman', 'size': 12})
    
    # 设置x轴和y轴的刻度标签，横坐标标签竖直显示
    plt.xticks(range(0, 7), labels=['UAV0', 'UAV1', 'UAV2', 'UAV3', 'UAV4', 'UAV5','UAV6'], rotation=90, ha='center', fontsize=10)
    plt.yticks(range(0, 7), labels=['UAV0', 'UAV1', 'UAV2', 'UAV3', 'UAV4', 'UAV5','UAV6'], fontsize=10)
    plt.show()

