import h5py
import numpy as np
import random
from numpy import sum, sqrt
from numpy.random import standard_normal, uniform, randint
import torchvision
from scipy import signal
from torch import nn
from sklearn.model_selection import train_test_split
import pywt
import matplotlib.pyplot as plt
from PIL import Image


def awgn(data):
    pkt_num = data.shape[0]
    SNRdB = -5
    #snr_range = np.arange(0, 11)
    #SNRdB = uniform(snr_range[0], snr_range[-1], pkt_num)  # 产生pkt_num个信噪比值，范围在snr_range最小值和最大值之间
    for pktIdx in range(pkt_num):
        s = data[pktIdx]
        #SNR_linear = 10 ** (SNRdB[pktIdx] / 10)
        SNR_linear = 10 ** (SNRdB/ 10)
        P = sum(abs(s) ** 2) / len(s)
        N0 = P / SNR_linear
        n = sqrt(N0 / 2) * (standard_normal(len(s)) + 1j * standard_normal(len(s)))#standard_mormal生成一个均值为0，标准差为1，符合高斯分布的随机数组
        data[pktIdx] = s + n
        #print(f"SNR for packet {pktIdx}: {SNRdB[pktIdx]:.2f} dB")
    return data
class STFTSpectrogram():
    def __init__(self, ):
        pass

    def _normalization(self, data):
        ''' Normalize the signal.'''
        s_norm = np.zeros(data.shape, dtype=complex)

        for i in range(data.shape[0]):
            sig_amplitude = np.abs(data[i])
            rms = np.sqrt(np.mean(sig_amplitude ** 2))
            s_norm[i] = data[i] / rms

        return s_norm


    def _spec_crop(self, x):
        num_row = x.shape[0]
        x_cropped = x[round(num_row * 0.3):round(num_row * 0.7)]

        return x_cropped

    def gen_stft_spectrogram(self, sig, win_len= 256, overlap= 128):
        f, t, spec = signal.stft(sig,
                                 window='boxcar',
                                 nperseg=win_len,  #窗函数长度
                                 noverlap=overlap,
                                 nfft=win_len,    #FFT长度，默认是窗函数长度，如果大于窗函数长度，会自动进行零填充
                                 return_onesided=False,
                                 padded=False,
                                 boundary=None)
        spec = np.fft.fftshift(spec, axes=0)
        chan_ind_spec = spec[:, 1:] / spec[:, :-1]

        # Take the logarithm of the magnitude.
        chan_ind_spec_amp = np.log10(np.abs(spec) ** 2)

        return chan_ind_spec_amp

    def STFT_spectrogram(self, data):
        data = self._normalization(data)
        #print(data.shape)#data.shape=[样本个数，95463每个样本里面的IQ信号个数]
        num_sample = data.shape[0]
        #num_row = 256
        num_row = int(256 * 0.4)

        num_column = int(np.floor((data.shape[1] - 256) / 128)+1)

        data_dspec = np.zeros([num_sample, 1, num_row, num_column])  #1表示谱图是单通道的，torch中channel在前面
        #在keras中是(num_samples, num_freq_bins, num_time_bins, channel)
        for i in range(num_sample):
            stft_spectrogram = self.gen_stft_spectrogram(data[i])
            stft_spectrogram = self._spec_crop(stft_spectrogram)
            data_dspec[i, 0, :, :] = stft_spectrogram          #直接返回傅里叶谱图

        return data_dspec

class LoadDataset():
    def __init__(self, ):
        self.dataset_name = 'data'
        self.labelset_name = 'label'

    def _convert_to_complex(self, data):
        '''Convert the loaded data to complex IQ samples.'''
        num_row = data.shape[0]
        num_col = data.shape[1]
        data_complex = np.zeros([num_row, round(num_col / 2)], dtype=complex)
        for i in range(0, num_col - 1, 2):
            data_complex[:, i // 2] = data[:, i] + 1j * data[:, i + 1]
        return data_complex

    def load_iq_samples(self, file_path, dev_range):

        f = h5py.File(file_path, 'r')
        label = f[self.labelset_name][:]
        label = label.astype(int)
        label = np.transpose(label)
        label = label - 1

        label_start = int(label.flatten()[0]) + 1
        label_end = int(label.flatten()[-1]) + 1
        num_dev = label_end - label_start + 1
        num_pkt = len(label)
        num_pkt_per_dev = int(num_pkt / num_dev)
        sample_index_list = []

        for dev_idx in dev_range:
            num_pkt = np.count_nonzero(label == dev_idx)
            pkt_range = np.arange(0, num_pkt, dtype=int)
            sample_index_dev = np.where(label == dev_idx)[0][
                pkt_range].tolist()  # 查找label中的标签值等于dev-idx，Where用于pkt_range里面提取对应的label的值
            sample_index_list.extend(sample_index_dev)
            print('Dev ' + str(dev_idx + 1) + ' have ' + str(num_pkt) + ' packets.')

        data = f[self.dataset_name][sample_index_list]  # 把data中的数据包和其标签对应起来
        data = self._convert_to_complex(data)
        label = label[sample_index_list]
        f.close()
        return data, label

def read_train_data(file_path='F:/neu_m046p309d/UAV_Mobilenet/data/ft9_train.h5',
              dev_range = np.arange(0, 7, dtype=int)):

    data_stft_all = []
    y_all = []

    LoadDatasetObj = LoadDataset()

    data_ch0, y_ch0 = LoadDatasetObj.load_iq_samples(file_path,
                                                 dev_range)
    data_ch0 = awgn(data_ch0)

    STFTSpectrogramObj = STFTSpectrogram()

    data_stft = STFTSpectrogramObj.STFT_spectrogram(data_ch0)
    data_stft_all.append(data_stft)
    y_all.append(y_ch0)

    data_stft_all = np.concatenate(data_stft_all, axis=0)
    y_all = np.concatenate(y_all)
    X_train, X_val, Y_train, Y_val = train_test_split(data_stft_all, y_all, test_size=0.2, random_state=32)
    return X_train, X_val, Y_train, Y_val

def read_test_data(file_path='F:/neu_m046p309d/UAV_Mobilenet/data/ft9_test.h5',
              dev_range = np.arange(0, 7, dtype=int)):
    data_stft_all = []
    y_all = []
    LoadDatasetObj = LoadDataset()

    data_ch0, y_ch0 = LoadDatasetObj.load_iq_samples(file_path,
                                                     dev_range)
    data_ch0 = awgn(data_ch0)
    STFTSpectrogramObj = STFTSpectrogram()
    data_stft = STFTSpectrogramObj.STFT_spectrogram(data_ch0)
    data_stft_all.append(data_stft)
    y_all.append(y_ch0)
    X_test = np.concatenate(data_stft_all, axis=0)
    Y_test = np.concatenate(y_all)
    return X_test, Y_test
if __name__ == "__main__":
    X_train, X_val, Y_train, Y_val = read_train_data()
    print(X_train.shape)
    X_test, Y_test = read_test_data()







