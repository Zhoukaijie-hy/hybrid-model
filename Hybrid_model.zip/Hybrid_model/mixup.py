import time
import torch.nn as nn
import torch
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader
from torch.utils.tensorboard import SummaryWriter
#from MobileNetV1_ResNet import *
from confusion_matrix import confusion
#from DCNN import my_resnet
import torchvision
from data_loader import *
from thop import profile as thop_profile
from torchsummary import summary
import random
import os
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from torchcam.methods import LayerCAM
import pandas as pd
import sys
#from my_model import my_resnet
#from IRMB import mynet
#sys.path.append('E:/CODE/deep learning/cai_code/models')
#from resnet_model import *
#from mobileVIT import *
from mynet075 import *

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed) # CPU
    torch.cuda.manual_seed(seed) # GPU
    torch.cuda.manual_seed_all(seed) # All GPU
    os.environ['PYTHONHASHSEED'] = str(seed) #设置pytorch内置hash函数种子，保证不同运行环境下字典等数据结构的哈希结果一致
    torch.backends.cudnn.deterministic = True # 确保每次返回的卷积算法是确定的
    torch.backends.cudnn.benchmark = False # True的话会自动寻找最适合当前配置的高效算法，来达到优化运行效率的问题。False禁用

class Config:
    def __init__(
        self,
        batch_size: int = 32,
        test_batch_size: int = 8,
        epochs: int = 50,
        lr: float = 0.001,
        save_path: str = 'F:/neu_m046p309d/UAV_Mobilenet/model_weight/mynet_0.5_mixup500.pth',
        device_num: int = 0,
        rand_num: int = 30,


        ):
        self.batch_size = batch_size
        self.test_batch_size = test_batch_size
        self.epochs = epochs
        self.lr = lr
        self.save_path = save_path
        self.device_num = device_num
        self.rand_num = rand_num
        self.train_lossses = []
        self.val_accuracies = []
def mixup_data(x, y, alpha=1.0, use_cuda=True):
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1

    batch_size = x.size()[0]
    if use_cuda:
        index = torch.randperm(batch_size)
    else:
        index = torch.randperm(batch_size)

    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def mixup_criterion(criterion, pred, y_a, y_b, lam):
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)

def train(model, train_dataloader, optimizer, epoch, writer, device_num, alpha=1.3):
    model.train()
    device = torch.device("cuda:"+str(device_num))
    correct = 0
    classifier_loss =0

    for data_nnl in train_dataloader:
        data, target = data_nnl
        target = target.squeeze().long()
        data, target_a, target_b, lam = mixup_data(data, target, alpha=alpha, use_cuda=torch.cuda.is_available())
        data, target_a, target_b = data.to(device), target_a.to(device), target_b.to(device)
        '''if torch.cuda.is_available():
            data = data.to(device)
            target = target.to(device)'''
        optimizer.zero_grad()
        output= model(data)#神经网络输出对应当前数据属于每个无人机类别的概率
        classifier_output = F.log_softmax(output, dim=1)#首先对输出进行softmax操作，计算每个类别概率的指数和，再归一化概率分布
        classifier_loss_batch = mixup_criterion(loss, classifier_output, target_a, target_b, lam)
        #classifier_loss_batch = loss(classifier_output, target)#
        result_loss_batch = classifier_loss_batch
        result_loss_batch.backward()
        optimizer.step()

        classifier_loss += classifier_loss_batch.item()
        pred = classifier_output.argmax(dim=1, keepdim=True)
        #correct += pred.eq(target.view_as(pred)).sum().item()
        correct += lam * pred.eq(target_a.view_as(pred)).sum().item() + (1 - lam) * pred.eq(target_b.view_as(pred)).sum().item()
    classifier_loss /= len(train_dataloader)
    print('Train Epoch: {} \tLoss: {:.6f}, Accuracy: {}/{} ({:0f}%)\n'.format(
        epoch,
        classifier_loss,
        correct,
        len(train_dataloader.dataset),
        100.0 * correct / len(train_dataloader.dataset))
    )                                                                  #打印轮数、分类器损失和准确率信息
    writer.add_scalar('Accuracy/train', 100.0 * correct / len(train_dataloader.dataset), epoch)
    writer.add_scalar('Loss/train', classifier_loss, epoch)
    #将损失数据和准确率保存到excel文件中
    with open('F:/neu_m046p309d/UAV_Mobilenet/log/train_log.txt', 'a') as f:
        f.write('epoch: ' + str(epoch) + ' ' + 'Accuracy: ' + str(100.0 * correct / len(train_dataloader.dataset)) + ' ' + 'Loss: ' + str(classifier_loss) + '\n')

    #用于训练准确率和分类器损失的可视化
    return classifier_loss


def evaluate(model, loss, val_dataloader, epoch, writer, device_num):
    model.eval()
    val_loss = 0
    correct = 0
    device = torch.device("cuda:"+str(device_num))
    with torch.no_grad():
        for data, target in val_dataloader:
            target = target.squeeze().long()
            if torch.cuda.is_available():
                data = data.to(device)
                target = target.to(device)
            output= features = model(data)
            output = F.log_softmax(output, dim=1)#将输出变为一个概率分布，
            val_loss += loss(output, target).item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()

    val_loss /= len(val_dataloader)
    fmt = '\nValidation set: loss: {:.4f}, Accuracy: {}/{} ({:0f}%)\n'
    print(
        fmt.format(
            val_loss,
            correct,
            len(val_dataloader.dataset),
            100.0 * correct / len(val_dataloader.dataset),
        )
    )
    accuracy = 100.0 * correct / len(val_dataloader.dataset)
    #需要查看准确率，损失和特征的可视化
    writer.add_scalar('Accuracy/validation', accuracy, epoch)
    writer.add_scalar('Loss/validation', val_loss, epoch)
    #将损失和准确率数据保存到txt文件中
    with open('F:/neu_m046p309d/UAV_Mobilenet/log/val_log.txt', 'a') as f:
        f.write('epoch: ' + str(epoch) + ' ' + 'Accuracy: ' + str(accuracy) + ' ' + 'Loss: ' + str(val_loss) + '\n')
    return val_loss, accuracy


def test(model, test_dataloader):
    model.eval()
    correct = 0
    features_list = []
    labels_list = []
    target_pred = []
    target_real = []
    t = 0
    i = 0

    with torch.no_grad():
        for data, target in test_dataloader:
            data.requires_grad_()
            start_time = time.time()
            target = target.long()
            if torch.cuda.is_available():
                data = data.cuda()
                target = target.cuda()

            output= features = model(data)

            end_time = time.time()
            sum = end_time-start_time
            t = t + sum
            i=i+1
            features_list.append(features.cpu().numpy())  # 保存特征
            labels_list.append(target.cpu().numpy())
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()
            target_pred[len(target_pred):len(target) - 1] = pred.tolist()  # 切片赋值的方式允许我们替换现有列表中的特定范围，以及将其他列表的元素添加到已有列表中的特定位置
            target_real[len(target_real):len(target) - 1] = target.tolist()  # target是真实标签的列表，target_pred是预测结果的列表
        t = t/i
        print("time for each epoch is: %s" % t)
        target_pred = np.array(target_pred)
        target_real = np.array(target_real)
    all_features = np.concatenate(features_list, axis=0)
    all_labels = np.concatenate(labels_list, axis=0)
    print(correct / len(test_dataloader.dataset))
    return target_pred, target_real, all_features, all_labels


def train_and_evaluate(model, loss_function, train_dataloader, val_dataloader, optimizer, epochs, writer, save_path, device_num):

    train_losses = []
    val_losses = []
    current_min_val_loss = 100                  #初始化当前最小的测试损失为一个较大的值，判断模型是否有改进
    #early_stopping = EarlyStopping(save_path)
    time_start1 = time.time()
    for epoch in range(1, epochs + 1):
        time_start = time.time()
        train_loss = train(model, train_dataloader, optimizer, epoch, writer, device_num, 0.5)
        train_losses.append(train_loss)
        val_loss, val_accuracy = evaluate(model, loss_function, val_dataloader, epoch, writer, device_num)
        val_losses.append(val_loss)
        if val_loss < current_min_val_loss:
            print("The validation loss is decreased from {} to {}, new model weight is saved.".format(
                current_min_val_loss, val_loss))
            current_min_val_loss = val_loss
            torch.save(model, save_path)
        else:
            print("The validation loss is not decreased.")
        time_end = time.time()
        time_sum = time_end - time_start
        print("time for each epoch is: %s" % time_sum)
        print("------------------------------------------------")
    time_end1 = time.time()
    Ave_epoch_time = (time_end1 - time_start1) / epochs
    print("Avgtime for each epoch is: %s" % Ave_epoch_time)
    return train_losses, val_losses

if __name__ == '__main__':
    conf = Config()                                                      #创建一个配置对象，存储各种配置参数
    writer = SummaryWriter("logs")
    device = torch.device("cuda:"+str(conf.device_num))
    RANDOM_SEED = 300  # any random number
    set_seed(RANDOM_SEED)

    run_for = 'Train'
    #run_for = 'Classification'
    if run_for == 'Train':

        X_train, X_val, Y_train, Y_val = read_train_data()
        print(X_train.shape)

        # 将训练预测数据集中的数据和标签封装成一个TensorDataset对象
        train_dataset = TensorDataset(torch.Tensor(X_train), torch.Tensor(Y_train))

        train_dataloader = DataLoader(train_dataset, batch_size=conf.batch_size, shuffle=True)
        
        X = torch.Tensor(X_train)
        Y = torch.Tensor(Y_train)
        print(X.size())
        print(Y.size())
        val_dataset = TensorDataset(torch.Tensor(X_val), torch.Tensor(Y_val))
        val_dataloader = DataLoader(val_dataset, batch_size=conf.batch_size, shuffle=True)
        model = mynet(num_classes=7)
        #print(model)
        X1 = X[:1]
        #print(X1.size())
        flops, params = thop_profile(model, inputs=(X1,))
        print('flops:{}'.format(flops))
        print('params:{}'.format(params))
        if torch.cuda.is_available():
            model = model.to(device)
        loss = nn.CrossEntropyLoss()
        if torch.cuda.is_available():
            loss = loss.to(device)
        summary(model, input_size=(1, 102, 389))
        optim = torch.optim.Adam(model.parameters(), lr=conf.lr, weight_decay=0)
        time_start = time.time()
        train_losses, val_losses = train_and_evaluate(model, loss_function=loss, train_dataloader=train_dataloader, val_dataloader=val_dataloader,
                       optimizer=optim, epochs=conf.epochs, writer=writer, save_path=conf.save_path,
                       device_num=conf.device_num)
        time_end = time.time()
        time_sum = time_end - time_start
        print("total training time is: %s" % time_sum)
        #print(train_losses)
        #print(val_losses)
        writer.close()
    elif run_for == 'Classification':

        X_test, Y_test, = read_test_data()
        test_dataset = TensorDataset(torch.Tensor(X_test), torch.Tensor(Y_test))
        test_dataloader = DataLoader(test_dataset)
        model = torch.load('model_weight/mynewnet_1.5_cutmix_6_12.pth')
        



        pred, real, features, labels = test(model, test_dataloader)
        confusion(pred, real, range(7))
        print(pred)
        num_features = features.shape[1] * features.shape[2] * features.shape[3]
        features_reshaped = features.reshape(-1, num_features)
        labels = labels.flatten()
        tsne = TSNE(n_components=2, random_state=0)
        features_2d = tsne.fit_transform(features_reshaped)
        plt.figure(figsize=(10, 8))
        num_classes = 7
        for i in range(num_classes):
            indices = labels == i
            plt.scatter(features_2d[indices, 0], features_2d[indices, 1], label=f'UAV{i+1}')
        plt.legend()
        plt.show()










